
public interface Shippable {
	//all interface methods are implicitly public, abstract
	String getName();
	double getWeight();
}
